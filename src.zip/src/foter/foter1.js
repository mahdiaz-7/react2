import React from 'react';
import Image1 from "./image/ecunion-8b792f56.png";
import Image2 from "./image/samandehi-6e2b448a.png";
import Image3 from "./image/1-min-6-250x230.png";
import Image4 from "./image/passenger-rights-48368f81.svg";
import Image5 from "./image/price.png";
import Image6 from "./image/state-airline-f45c55b2.svg";

const foter1 = () => {
    return (
        <div className='border-t-2 border-b-2  border-solid border-grey-300 p-8  pt-10 flex justify-center '>
            <div className='flex gap-12 w-3/5'>
                
            <div className='grid-cols-2 gap-4 text-right'>
                    <img src="https://cdn.alibaba.ir/h2/desktop/assets/images/shawl_logotype-d6b14ca0.svg" className='w-36	 h-7'/>

                    <div className='pb-4 '>
                        <p className='text-left pb-4 pt-4'>تلفن پشتیبانی: ۰۲۱-۴۳۹۰۰۰۰۰</p>
                        <span className='text-left'>دفتر پشتیبانی: اکباتان، نبش اتوبان لشگری، کوی بیمه، خیابان بیمه چهارم،
                             بن‌بست گل‌ها، پلاک 1</span>
                    </div>
                    <div className='flex pt-6'>
                            <ul className='list-n flex'>
                                <div className='p-2 pl-0 cursor-pointer'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image1}/>
                                </li>
                                </div>
                                <div className='p-2 cursor-pointer'>

                                <li className='w-20 border solid rounded p-2'>
                                    <img src={Image2}/>
                                </li>
                                </div>
                                <div className='p-2 cursor-pointer'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image3}/>
                                </li>
                                </div>
                                <div className='p-2 cursor-pointer'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image4}/>
                                </li>
                                </div>
                                <div className='p-2 cursor-pointer'>

                                <li className='w-20  h-20 border solid rounded p-2'>
                                    <img src={Image5}/>
                                </li>
                                </div>
                                <div className='p-2 cursor-pointer'>

                                <li className='w-20 h-20 border solid rounded p-2'>
                                    <img src={Image6}/>
                                </li>
                                </div>
                            </ul>
                    </div>
                </div>
                
            <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4 font-bold'>اطلاعات تکمیلی</h4>
                    <ul>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>باشگاه همسفران</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>فروش سازمانی</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>همکاری با آژانس‌ها</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>فرصت‌های شغلی</a>
                        </li>
                    </ul>
                </div>              
                <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4 font-bold'>خدمات مشتریان</h4>
                    <ul>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>مرکز پشتیبانی آنلاین</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>راهنمای خرید</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>راهنمای استرداد</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>قوانین و مقررات</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>پرسش و پاسخ</a>
                        </li>
                    </ul>
                </div>
                <div className='grid-cols-2 gap-4 text-right	'>
                    <h4 className='text-l mb-4 font-bold'>علی بابا</h4>
                    <ul>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>درباره ما</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>تماس با ما</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>چرا علی‌بابا</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>علی بابا پلاس</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>بیمه مسافرتی</a>
                        </li>
                        <li className='hover:text-slate-600	'>
                            <a className='cursor-pointer'>مجله علی‌بابا</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default foter1   ;