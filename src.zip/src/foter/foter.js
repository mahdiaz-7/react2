import React from 'react';
import Star from "./image/download.webp"
import Star1 from "./image/download (1).webp";
import Star2 from "./image/download (2).webp";
const Foter = () => {
    return (
        <div className='mt-24 h-24  border-t-2 border-solid border-grey-300 mb-16 '>
            <div className='flex  justify-center '>
              <div className='flex p-10 w-3/5 '>
                    
                <div className='grid-cols-4	'>
                    <div className='flex'>

                    <div className='text-right'>
                            <h3 className='text-gray-800 font-bold'>همسفر همه لحظات سفر</h3>
                            <span className='text-gray-600'>پشتیبانی و همراهی ۲۴ ساعته در تمامی مراحل سفر</span>
                        </div>
                        <div className=' pl-4'>
                            <img src={Star2} className='w-28 h-20' />
                        </div>
                    </div>
                       
                    </div>
                    <div className='grid-cols-4	'>
                        <div className='flex'>
                            
                    <div className='text-right '>
                            <h3 className='text-gray-800 font-bold'>همسفر هر سفر</h3>
                            <span className='text-gray-600' >ارائه تمامی خدمات سفر (پرواز، قطار، اتوبوس، هتل و تور)</span>
                        </div>
                        <div className='pl-4'>
                            <img src={Star1} className='w-28 h-20'  />
                        </div>
                        </div>
                       
                    </div>
                    <div className='grid-cols-4	'>
                        <div className='flex'>

                        <div className='text-right '>
                            <h3 className='text-gray-800 font-bold'>رتبه یک سفر</h3>
                            <span className='text-gray-600'>معتبرترین عرضه‌کننده محصولات   گردشگری در ایران</span>
                        </div>
                        <div className='pl-4'>
                            <img src={Star}  className='w-28 h-22'  />
                        </div>
                       
                    </div> 
                    </div> 
                </div>
                
            </div>
        </div>
    );
};

export default Foter;