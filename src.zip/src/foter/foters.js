import React from 'react';
import Foter3 from "./foter";
import Foter1 from "./foter1";
import Foter2 from "./foter2";

const foters = () => {
    return (
        <div>
            
            <Foter3/>
            <Foter1/>
            <Foter2/>
        </div>
    );
};

export default foters;