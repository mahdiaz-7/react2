import React from 'react';
import { ImLinkedin} from 'react-icons/im';
import { BsInstagram } from "react-icons/bs";
import {SiAparat } from "react-icons/si";
import {BsTwitter} from "react-icons/bs";
import {BsYoutube} from "react-icons/bs";
import {FaTelegramPlane} from "react-icons/fa";

const Foter2 = () => {
    return (
        <div className='flex text-center justify-center'>
            
            <div className='flex text-gray-400 p-4'>
                <div  className='p-4 cursor-pointer'><h5><ImLinkedin className='w-6 h-6'/></h5></div>
               <div  className='p-4 cursor-pointer'><h5><BsInstagram className='w-6 h-6'/></h5></div>
               <div  className='p-4 cursor-pointer'><h5><SiAparat className='w-6 h-6'/></h5></div>
               <div  className='p-4 cursor-pointer'><h5><BsTwitter className='w-6 h-6'/></h5></div>
               <div  className='p-4 cursor-pointer'><h5><BsYoutube className='w-6 h-6'/></h5></div>
               <div  className='p-4 cursor-pointer'><h5><FaTelegramPlane className='w-6 h-6'/></h5></div>
            </div>
            <div className='mt-8 ml-12'>
                <span className='text-gray-400 text-sm'>
                کلیه حقوق این سرویس (وب‌سایت و اپلیکیشن‌های موبایل) محفوظ و متعلق به شرکت سفرهای علی‌بابا می‌باشد. (نسخه 2.36.3)
                </span>
            </div>
        </div>
    );
};

export default Foter2;