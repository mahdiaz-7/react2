import React from "react";
import Image from "./image/download.gif";
import Btn from "./menu/menu1";
function Header() {
  return (
    <div
      className=" shadow-sm border-b    flex 	h-16  justify-center	"
      id="header"
    >
      <div className="flex 	space-x-64 p-2 ">
        <div className="flex w-fit  py-1 px-4 w-1/4		">
          <div className="flex cursor-pointer hover:bg-gray-100 rounded-lg text-zinc-500  text-gray-800 ">
            <div className="flex  	 m-2 justify-center">
              <div>
                <span>ورود یا ثبت نام</span>
              </div>
              <div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="flex cursor-pointer hover:bg-gray-100 rounded-lg text-zinc-500 text-gray-800 ">
            <div className="flex rounded-lg	m-2">
              <div>
                <span> سفرهای من</span>
              </div>
              <div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"
                  />
                </svg>
              </div>
            </div>
          </div>
          <div className="flex cursor-pointer hover:bg-gray-100 rounded-lg text-zinc-500 text-gray-800 ">
            <div className="flex h-7  rounded-lg m-2">
              <div>
                <span>مرکز پشتیبانی آنلاین</span>
              </div>
              <div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
        <div className="flex h-16 py-1 px-4 w-5/12">
          <div className="flex h-6  divide-x">
            <div>
              <button class="text-zinc-500 ml-2	  flex bg-white hover:bg-gray-100 rounded text-gray-800 font-semibold py-2 px-4  mr-2 ">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 8.25l-7.5 7.5-7.5-7.5"
                  />
                </svg>
                اقامت
              </button>
            </div>
            <div>
              <button class="text-zinc-500 	ml-2  flex bg-white hover:bg-gray-100 rounded text-gray-800 font-semibold py-2 px-4  mr-2 ">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 8.25l-7.5 7.5-7.5-7.5"
                  />
                </svg>
                تور
              </button>
            </div>
            <div>
              <div class="text-zinc-500 cursor-pointer	ml-2  flex bg-white hover:bg-gray-100 rounded text-gray-800 font-semibold py-2 px-4  mr-2  ">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-6 h-6"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M19.5 8.25l-7.5 7.5-7.5-7.5"
                  />
                </svg>
                بیشتر
              </div>
              </div>
              <div>
                <div>
                  <Btn/>
                </div>
              
            </div>
          </div>
          <div>
            <img src={Image} className="h-10  w-48 " />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
